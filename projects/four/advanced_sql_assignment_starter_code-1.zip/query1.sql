-- Find all film_ids of films with minimum length or maximum rental duration (compared to all other films). The returned list of film_ids should be sorted in descending order.

-- Put query for Q1 here

