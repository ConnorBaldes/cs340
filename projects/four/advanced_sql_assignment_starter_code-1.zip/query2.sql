-- For each category of film, find the name of the category (as "category_name") and the count of films (as "number_of_films") that MAE HOFFMAN has stared in within that category. 
-- Order by the category name in descending order. 
-- (Note: your query should return every category even if MAE has been in no films in that category--i.e., her count is 0 for "number_of_films" for that respective "category_name").

-- Put query for Q2 here

