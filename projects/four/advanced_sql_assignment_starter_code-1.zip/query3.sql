-- For each actor, find the actor_id, first_name, last_name and total_combined_film_length of "Animation" films for that actor.
-- Order your results by the actor_id in ascending order. 
-- (Note: actors who have not stared in any animation films would have a total_combined_film_length of 0).

-- Put query for Q3 here

